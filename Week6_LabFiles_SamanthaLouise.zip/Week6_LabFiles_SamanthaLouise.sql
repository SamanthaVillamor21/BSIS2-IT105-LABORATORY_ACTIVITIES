-- CREATE DATABASE
CREATE DATABASE IntegrityLab;
USE IntegrityLab;

-- CREATE CUSTOMERS TABLE
CREATE TABLE Customers (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    PhoneNumber VARCHAR(15) NOT NULL,
    CONSTRAINT chk_phone_length CHECK (CHAR_LENGTH(PhoneNumber) = 11)
);

-- CREATE ORDERS TABLE
CREATE TABLE Orders (
    OrderID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT NOT NULL,
    OrderDate DATE NOT NULL,
    TotalAmount DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_totalamount_positive CHECK (TotalAmount > 0),
    FOREIGN KEY (CustomerID)
        REFERENCES Customers(CustomerID)
        ON DELETE CASCADE
);

-- CREATE AUDIT TABLE
CREATE TABLE OrderAudit (
    AuditID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT,
    ActionType VARCHAR(50),
    ActionTimestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CREATE INDEX
CREATE INDEX idx_orders_customerid
ON Orders(CustomerID);

-- JOIN QUERY
SELECT c.Name, o.OrderID, o.TotalAmount
FROM Customers c
JOIN Orders o ON c.CustomerID = o.CustomerID
WHERE c.CustomerID = 5000;

-- UPDATE QUERY
UPDATE Customers
SET PhoneNumber = '09123456789'
WHERE CustomerID = 2;

-- DELETE QUERY
DELETE FROM Orders WHERE OrderID = 5;

-- TWO SELECT QUERIES
SELECT * FROM Customers LIMIT 10;

SELECT COUNT(*) AS TotalOrders FROM Orders;

-- TRANSACTION ROLLBACK TEST
START TRANSACTION;

UPDATE Orders
SET TotalAmount = TotalAmount + 100
WHERE CustomerID = 5000;

ROLLBACK;

-- TRANSACTION COMMIT TEST
START TRANSACTION;

UPDATE Orders
SET TotalAmount = TotalAmount + 100
WHERE CustomerID = 5000;

COMMIT;

-- CREATE TRIGGER FOR AUDIT
DELIMITER $$

CREATE TRIGGER OrderDeleteLog
AFTER DELETE ON Orders
FOR EACH ROW
BEGIN
    INSERT INTO OrderAudit (OrderID, ActionType)
    VALUES (OLD.OrderID, 'DELETED');
END$$

DELIMITER ;

-- TEST AUDIT LOG
DELETE FROM Orders WHERE OrderID = 1;

SELECT * FROM OrderAudit;